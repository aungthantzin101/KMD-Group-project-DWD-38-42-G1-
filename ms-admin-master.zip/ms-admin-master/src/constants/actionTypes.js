export const CREATE_SHOP = 'CREATE_SHOP';
export const FETCH_SHOP = 'FETCH_SHOP';
export const FETCH_SHOP_NAME = 'FETCH_SHOP_NAME';
export const IS_SHOP_LOADING = 'IS_SHOP_LOADING';
export const IS_ERROR = 'IS_ERROR';
export const IMAGE_ERROR = 'IMAGE_ERROR';
